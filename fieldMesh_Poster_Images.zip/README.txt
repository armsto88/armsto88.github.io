fieldMesh poster image assets — poster v35

01–03: original PNG artwork, at original resolution. Node renders retain original transparency.
04: deployment image with final heading, Wi-Fi icons and legend.
05–08: assembled workflow panels exported from the PDF at 144 dpi at their A0 size.
09–11: original dashboard and phone app images used in the panels.
12–15: fieldMesh and organisation logos.
16–17: QR codes exported from the poster.

These are existing poster assets, not newly generated artwork. Native raster images have not been upscaled.
